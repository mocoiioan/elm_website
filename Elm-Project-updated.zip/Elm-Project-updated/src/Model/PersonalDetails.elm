module Model.PersonalDetails exposing (..)

import Html exposing (..)
import Html.Attributes exposing (class, classList, id, href)


type alias DetailWithName =
    { name : String
    , detail : String
    }


type alias PersonalDetails =
    { name : String
    , contacts : List DetailWithName
    , intro : String
    , socials : List DetailWithName
    }

view : PersonalDetails -> Html msg
view details =
     div [] [
        h1 [id "name"][text details.name],
        em [id "intro"][text details.intro],
        li [] (details.contacts |> List.map getContact),
        li [] (details.socials |> List.map getSocialLink)
     ]
    -- Debug.todo "Implement the Model.PersonalDetails.view function"

getContact : DetailWithName -> Html msg
getContact contact = 
    li [class "contact-detail"][text contact.name, text contact.detail]

getSocialLink : DetailWithName -> Html msg
getSocialLink link = 
    li [class "social-link"][a [href link.detail][text link.name]]